package AndroidAutomation.android;

import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import junit.framework.Assert;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class StartApplication {

		private static AndroidDriver driver;
		
		@BeforeSuite
		public static void main(String[] args) throws MalformedURLException, InterruptedException {

			desired();
			
	}

		private static void desired() throws MalformedURLException, InterruptedException {
			DesiredCapabilities capabilities = new DesiredCapabilities();
			
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "OnePlus 6");
			//capabilities.setCapability(MobileCapabilityType.UDID,"3BCEA150258C3A09");
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "10");
			capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
			
		capabilities.setCapability("appPackage", "in.amazon.mShop.android.shopping");
		capabilities.setCapability("appActivity", "com.amazon.mShop.home.HomeActivity");
		capabilities.setCapability("noReset", "true");
		
			driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
			Thread.sleep(10000);
		}
		 @AfterSuite
		  public void uninstallApp() throws InterruptedException {
		   // driver.removeApp("in.amazon.mShop.android.shopping");
		  }
			  @Test (enabled=true) public void mytest() throws InterruptedException, MalformedURLException {
				  desired();
				  driver.findElementByXPath("//android.widget.ImageView[@content-desc='Navigation panel, button, double tap to open side panel']").click();
				  driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
				    driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Language A/क\"));");
			
				    driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
					
					WebElement Menu = driver.findElementByXPath("//*[@text='Settings']");
							
							  Assert.assertEquals(Menu.getText(), "Settings");
					driver.findElementByXPath("//*[@text='Settings']").click();
					driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

	}

			 
}