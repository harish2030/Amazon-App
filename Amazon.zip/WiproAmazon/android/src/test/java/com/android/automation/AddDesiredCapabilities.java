/*
 * This Class provides pre-conditions to set device capabilities
 */


package com.android.automation;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

class AddDesiredCapabilities {
	
	private static DesiredCapabilities capabilities = new DesiredCapabilities(); ////initialize DesiredCapabilities
	public static AndroidDriver driver;
	
	/*
	 * Constructor to load all the DesiredCapabilities
	 */
	
	public static void initilializedesiredCap() throws MalformedURLException, InterruptedException {
	
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "OnePlus 6");
		//capabilities.setCapability(MobileCapabilityType.UDID,"3BCEA150258C3A09");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "10");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		
	capabilities.setCapability("appPackage", "com.amazon.mShop.android.shopping");
	capabilities.setCapability("appActivity", "com.amazon.mShop.home.HomeActivity");
	capabilities.setCapability("noReset", "true");
	
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		
	}

}
