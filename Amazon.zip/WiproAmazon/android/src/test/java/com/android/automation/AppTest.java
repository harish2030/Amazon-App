package com.android.automation;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterSuite;

/*
 * This class provides element identification and assertions.
 * 
 * in @Test using the amazon apk, launching the application and navigate to settings page.
 */

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class AppTest {

	//initialize 
	

	@Test
	public void test() {
		
		AddDesiredCapabilities.driver.findElementByXPath(
				"//android.widget.ImageView[@content-desc='Navigation panel, button, double tap to open side panel']")
				.click();
		AddDesiredCapabilities.driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
		AddDesiredCapabilities.driver.findElementByAndroidUIAutomator(
				"new UiScrollable(new UiSelector()).scrollIntoView(text(\"Language A/क\"));");

		AddDesiredCapabilities.driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

		WebElement Menu = AddDesiredCapabilities.driver.findElementByXPath("//*[@text='Settings']");

		Assert.assertEquals(Menu.getText(), "Settings");
		AddDesiredCapabilities.driver.findElementByXPath("//*[@text='Settings']").click();
		AddDesiredCapabilities.driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);

	}

	@BeforeSuite
	public void beforeSuite() {

		try {
			AddDesiredCapabilities.initilializedesiredCap();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@AfterSuite
	public void afterSuite() {
		   // driver.removeApp("in.amazon.mShop.android.shopping");

	}

}
