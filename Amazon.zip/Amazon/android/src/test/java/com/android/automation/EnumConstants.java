/*
 * This class contains Constants
 */

package com.android.automation;

class Constants
{
	public final static String VERSION="10";
	public final static String ONEPLUS_6="OnePlus 6";
	public final static String ANDROID="Android";
	public final static String PACKAGE ="appackage";
	public final static String ACTIVITY="appActivity";
	public final static String RESET="noRest";

	public final static String APPPACKAGE ="in.amazon.mShop.android.shopping";
	public final static String APPACTIVITY="com.amazon.mShop.home.HomeActivity";
	public final static String NORESET="true";
	
	public final static String URI="http://127.0.0.1:4723/wd/hub";
	}